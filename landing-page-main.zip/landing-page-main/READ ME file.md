# Landing Page Project

This is a responsive landing page built using HTML, CSS, and JavaScript.

## Features
- Hero section
- Features section
- CTA section
- Responsive design

## Tech Used
- HTML
- CSS
- JavaScript